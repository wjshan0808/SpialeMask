#!/bin/sh
#项目SpialeMask编译链接后执行脚本
#
echo $1
